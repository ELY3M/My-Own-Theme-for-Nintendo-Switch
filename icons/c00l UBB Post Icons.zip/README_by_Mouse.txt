those kickass posticons

Thanks to ubbdev.com and Joe Stilgar

just go to www.mysmilies.com for more kickass smilies or posticons

you just need to rename the filenames to after icons14.gif in your 

icons15.gif and after

icons folder in ubb folder.  


< :3 M o u s e ~~~